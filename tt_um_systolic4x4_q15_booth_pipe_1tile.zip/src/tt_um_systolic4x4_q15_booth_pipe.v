`timescale 1ns / 1ps
//================================================================
// tt_um_systolic4x4_q15_booth_pipe  (1-tile version)
//----------------------------------------------------------------
// One serial radix-4 Booth multiply-accumulate engine (the same
// pe_q15_booth4_serial used in the 16-PE array) driven byte-serially.
// A 4x4 matrix product is 16 dot products of 4 terms; the host feeds
// the operand pairs, the chip accumulates and returns each result.
//
// Per dot product C[i][j] = sum_k A[i][k]*B[k][j]  (k = 0..3):
//   LOAD  : 4 bytes per term via strobe (uio[0]), MSB first:
//           A[i][k] hi, A[i][k] lo, B[k][j] hi, B[k][j] lo
//   FEED/WAIT : term is multiplied-accumulated (8 clocks, busy=1)
//   after the 4th term -> READ : 4 bytes of the signed 32-bit sum,
//           MSB first, one per strobe. Then back to LOAD (k = 0).
//
// Status on uio_out: [1] busy [2] done pulse [3] load phase
//   [4] 0 [5] compute (= busy) [6] read phase [7] byte_valid
//================================================================
module tt_um_systolic4x4_q15_booth_pipe
(
    input  wire [7:0] ui_in,
    output wire [7:0] uo_out,
    input  wire [7:0] uio_in,
    output wire [7:0] uio_out,
    output wire [7:0] uio_oe,
    input  wire       ena,
    input  wire       clk,
    input  wire       rst_n
);
    wire rst    = ~rst_n;
    wire strobe = uio_in[0];

    assign uio_oe = 8'b1111_1110;

    localparam PH_LOAD = 2'd0;
    localparam PH_FEED = 2'd1;
    localparam PH_WAIT = 2'd2;
    localparam PH_READ = 2'd3;

    reg [1:0]  phase;
    reg [31:0] sh;        // {A hi, A lo, B hi, B lo}
    reg [1:0]  bcnt;      // byte within a term (load) / byte within result (read)
    reg [1:0]  k;         // term index 0..3
    reg [2:0]  wcnt;      // wait counter (8 clocks of Booth iteration)
    reg        done_r;

    wire feed = (phase == PH_FEED);

    wire signed [31:0] acc;
    wire signed [15:0] a_unused, b_unused;
    wire v_unused, av_unused;

    pe_q15_booth4_serial #(.N(4)) MAC
    (
        .clk(clk), .rst(rst),
        .valid_in(feed),
        .acc_clear(feed && (k == 2'd0)),
        .a_in(sh[31:16]),
        .b_in(sh[15:0]),
        .a_out(a_unused), .b_out(b_unused),
        .acc_out(acc),
        .valid_out(v_unused), .acc_valid(av_unused)
    );

    always @(posedge clk or posedge rst)
    begin
        if (rst)
        begin
            phase  <= PH_LOAD;
            bcnt   <= 2'd0;
            k      <= 2'd0;
            wcnt   <= 3'd0;
            done_r <= 1'b0;
        end
        else
        begin
            done_r <= 1'b0;
            case (phase)
            PH_LOAD:
                if (strobe)
                begin
                    bcnt <= bcnt + 2'd1;
                    if (bcnt == 2'd3)
                        phase <= PH_FEED;
                end
            PH_FEED:
            begin
                phase <= PH_WAIT;
                wcnt  <= 3'd0;
            end
            PH_WAIT:
            begin
                wcnt <= wcnt + 3'd1;
                if (wcnt == 3'd7)
                begin
                    k <= k + 2'd1;
                    if (k == 2'd3)
                    begin
                        phase  <= PH_READ;
                        done_r <= 1'b1;
                    end
                    else
                        phase <= PH_LOAD;
                end
            end
            default: // PH_READ
                if (strobe)
                begin
                    bcnt <= bcnt + 2'd1;
                    if (bcnt == 2'd3)
                        phase <= PH_LOAD;
                end
            endcase
        end
    end

    // input byte shift register (no reset needed)
    always @(posedge clk)
        if (phase == PH_LOAD && strobe)
            sh <= {sh[23:0], ui_in};

    // result byte, MSB first
    reg [7:0] rbyte;
    always @(*)
        case (bcnt)
            2'd0:    rbyte = acc[31:24];
            2'd1:    rbyte = acc[23:16];
            2'd2:    rbyte = acc[15:8];
            default: rbyte = acc[7:0];
        endcase

    wire rd = (phase == PH_READ);
    assign uo_out = rd ? rbyte : 8'd0;

    assign uio_out[0] = 1'b0;
    assign uio_out[1] = (phase == PH_FEED) || (phase == PH_WAIT);
    assign uio_out[2] = done_r;
    assign uio_out[3] = (phase == PH_LOAD);
    assign uio_out[4] = 1'b0;
    assign uio_out[5] = (phase == PH_FEED) || (phase == PH_WAIT);
    assign uio_out[6] = rd;
    assign uio_out[7] = rd;

    wire _unused = &{ena, a_unused, b_unused, v_unused, av_unused, 1'b0};
endmodule
