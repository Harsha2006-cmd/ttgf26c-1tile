`timescale 1ns / 1ps
//================================================================
// pe_q15_booth4_serial
//----------------------------------------------------------------
// One processing element of the 4x4 systolic array.
//
// Multiply-accumulate with an ITERATIVE radix-4 modified Booth
// multiplier: one Booth digit (8 digits for a 16-bit multiplier)
// is added into the accumulator per clock, so one a*b term costs
// TERM_PERIOD = 8 cycles. Sign handling is two's complement mod
// 2^32 (exact, since a 16x16 signed product always fits in 32 bits).
//
// Operand forwarding (systolic hop) takes exactly 1 cycle:
//   valid_in at cycle t  ->  valid_out, a_out, b_out at cycle t+1.
// a_out/b_out are taken directly from the working registers, and
// are only meaningful in the cycle where valid_out is high.
//
// A new term must not be presented earlier than 8 cycles after the
// previous one (matrix_loader4x4 guarantees this).
//
// acc_clear must be high in the same cycle as the first valid_in of
// a new dot product. acc_valid pulses once when the Nth term has
// been fully added into acc_out; acc_out then holds the result until
// the next dot product starts.
//================================================================
module pe_q15_booth4_serial
#(
    parameter N = 4          // terms per dot product
)
(
    input  clk,
    input  rst,

    input  valid_in,
    input  acc_clear,

    input  signed [15:0] a_in,
    input  signed [15:0] b_in,

    output signed [15:0] a_out,
    output signed [15:0] b_out,

    output signed [31:0] acc_out,

    output reg valid_out,
    output reg acc_valid
);

    localparam CW = (N < 2) ? 1 : $clog2(N + 1);

    // working registers (no reset needed: only used while `run`)
    reg [31:0] a_sh;    // multiplicand, sign-extended, shifted left 2 per step
    reg [16:0] b_sh;    // {multiplier, 0}, shifted right (arith) 2 per step

    reg [31:0] acc;         // no reset: cleared by the first term of every dot product

    reg        run;
    reg [2:0]  step;
    reg        last_term;   // this term is the Nth of its dot product
    reg [CW-1:0] term_cnt;

    assign a_out   = a_sh[15:0];
    assign b_out   = b_sh[16:1];
    assign acc_out = acc;

    // Booth digit from the low 3 bits of b_sh
    wire b2 = b_sh[2];
    wire b1 = b_sh[1];
    wire b0 = b_sh[0];

    wire sel_one = b1 ^ b0;
    wire sel_two = (b2 & ~b1 & ~b0) | (~b2 & b1 & b0);
    wire neg     = b2;

    wire [31:0] mag    = sel_one ? a_sh :
                         sel_two ? {a_sh[30:0], 1'b0} : 32'd0;
    wire [31:0] addend = mag ^ {32{neg}};
    wire [31:0] base   = acc;
    wire        clr    = valid_in && acc_clear;   // first term: restart the sum at 0

    // ripple-carry adder: sum = base + addend + neg (mod 2^32).
    // Ripple carry is the smallest adder; the multi-cycle iteration
    // leaves plenty of time for it at the target clock.
    wire [32:0] cy;
    wire [31:0] sum;
    assign cy[0] = neg;
    genvar gi;
    generate
        for (gi = 0; gi < 32; gi = gi + 1) begin : g_fa
            assign sum[gi]  = base[gi] ^ addend[gi] ^ cy[gi];
            assign cy[gi+1] = (base[gi] & addend[gi]) | (cy[gi] & (base[gi] ^ addend[gi]));
        end
    endgenerate

    wire [CW-1:0] cnt_new = acc_clear ? {{(CW-1){1'b0}}, 1'b1} : (term_cnt + 1'b1);

    always @(posedge clk or posedge rst)
    begin
        if (rst)
        begin
            run       <= 1'b0;
            step      <= 3'd0;
            last_term <= 1'b0;
            term_cnt  <= {CW{1'b0}};
            valid_out <= 1'b0;
            acc_valid <= 1'b0;
        end
        else
        begin
            valid_out <= valid_in;
            acc_valid <= run && (step == 3'd7) && last_term;

            if (run)
            begin
                step <= step + 3'd1;
                if (step == 3'd7)
                    run <= 1'b0;
            end

            if (valid_in)
            begin
                run       <= 1'b1;
                step      <= 3'd0;
                term_cnt  <= cnt_new;
                last_term <= (cnt_new == N);
            end
        end
    end

    // Datapath registers, no reset. They keep iterating while idle:
    // after 8 shifts b_sh holds only sign bits, i.e. Booth digit 0
    // (000 or 111), which adds exactly zero, so acc simply holds its
    // value between terms without needing a hold multiplexer.
    always @(posedge clk)
    begin
        acc <= clr ? 32'd0 : sum;
        if (valid_in)
        begin
            a_sh <= {{16{a_in[15]}}, a_in};
            b_sh <= {b_in, 1'b0};
        end
        else
        begin
            a_sh <= {a_sh[29:0], 2'b00};
            b_sh <= {{2{b_sh[16]}}, b_sh[16:2]};
        end
    end

endmodule
