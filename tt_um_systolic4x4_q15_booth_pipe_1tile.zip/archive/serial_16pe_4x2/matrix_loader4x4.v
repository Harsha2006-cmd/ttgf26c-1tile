`timescale 1ns / 1ps
//================================================================
// matrix_loader4x4
//
// Streams two parallel 4x4 matrices into the systolic array, one
// dot-product term (k = 0..3) every PERIOD cycles. PERIOD must be at
// least the PE's multiply time (8 cycles for the serial Booth PE).
//
//   a_row0..3 = A[row][k]   (A element moving across row `row`)
//   b_col0..3 = B[k][col]   (B element moving down column `col`)
//   valid     = 1-cycle pulse at the start of each term
//   acc_clear = valid && (k == 0): COMBINATIONALLY aligned with the
//               first valid pulse of a stream, as the array requires.
//
// The matrices are NOT copied here: the input buses are read
// directly through 4:1 muxes, so the caller (the Tiny Tapeout
// wrapper's a_mem/b_mem) must hold them stable while `start` ..
// the array's final done is in progress. This removes 512
// duplicate flops compared with the original loader.
//================================================================
module matrix_loader4x4
#(
    parameter DW     = 16,
    parameter PERIOD = 8
)
(
    input clk,
    input rst,
    input start,

    input signed [DW-1:0] a00, a01, a02, a03,
    input signed [DW-1:0] a10, a11, a12, a13,
    input signed [DW-1:0] a20, a21, a22, a23,
    input signed [DW-1:0] a30, a31, a32, a33,

    input signed [DW-1:0] b00, b01, b02, b03,
    input signed [DW-1:0] b10, b11, b12, b13,
    input signed [DW-1:0] b20, b21, b22, b23,
    input signed [DW-1:0] b30, b31, b32, b33,

    output signed [DW-1:0] a_row0, a_row1, a_row2, a_row3,
    output signed [DW-1:0] b_col0, b_col1, b_col2, b_col3,

    output valid,
    output acc_clear
);

    localparam CW = $clog2(PERIOD);

    reg          streaming;
    reg [1:0]    k;
    reg [CW-1:0] cnt;

    assign valid     = streaming && (cnt == {CW{1'b0}});
    assign acc_clear = valid && (k == 2'd0);

    always @(posedge clk or posedge rst)
    begin
        if (rst)
        begin
            streaming <= 1'b0;
            k         <= 2'd0;
            cnt       <= {CW{1'b0}};
        end
        else if (!streaming)
        begin
            if (start)
            begin
                streaming <= 1'b1;
                k         <= 2'd0;
                cnt       <= {CW{1'b0}};
            end
        end
        else
        begin
            if (cnt == PERIOD - 1)
            begin
                cnt <= {CW{1'b0}};
                if (k == 2'd3)
                    streaming <= 1'b0;
                else
                    k <= k + 2'd1;
            end
            else
                cnt <= cnt + 1'b1;
        end
    end

    function signed [DW-1:0] sel4;
        input signed [DW-1:0] v0, v1, v2, v3;
        input [1:0] s;
        begin
            case (s)
                2'd0:    sel4 = v0;
                2'd1:    sel4 = v1;
                2'd2:    sel4 = v2;
                default: sel4 = v3;
            endcase
        end
    endfunction

    //------------------------------------------------------------
    // Operand skew. A row r (and B column c) must reach the array r
    // (c) cycles after row 0 (column 0). Instead of delaying 16-bit
    // data through registers, the 2-bit term pointer k is delayed:
    // kd[i] = k delayed by i cycles (SKEW_LAT cycles per hop).
    // Row r / column c then selects the same element one hop later,
    // which is exactly the original skew, for 6 flops instead of 192.
    //------------------------------------------------------------
    reg [1:0] kd1, kd2, kd3;
    always @(posedge clk)
    begin
        kd1 <= k;
        kd2 <= kd1;
        kd3 <= kd2;
    end

    assign a_row0 = sel4(a00, a01, a02, a03, k);
    assign a_row1 = sel4(a10, a11, a12, a13, kd1);
    assign a_row2 = sel4(a20, a21, a22, a23, kd2);
    assign a_row3 = sel4(a30, a31, a32, a33, kd3);

    assign b_col0 = sel4(b00, b10, b20, b30, k);
    assign b_col1 = sel4(b01, b11, b21, b31, kd1);
    assign b_col2 = sel4(b02, b12, b22, b32, kd2);
    assign b_col3 = sel4(b03, b13, b23, b33, kd3);

endmodule
