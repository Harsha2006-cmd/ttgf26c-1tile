# SPDX-FileCopyrightText: (c) 2026 H S Harsha
# SPDX-License-Identifier: Apache-2.0
#
# Cocotb tests for tt_um_systolic4x4_q15_booth_pipe (16-PE systolic array,
# serial radix-4 Booth PEs). Results are checked against an independent
# Python reference model: C = A x B, signed 16x16 products accumulated
# and wrapped to signed 32 bit (no Q15 rescale; outputs are raw Q30 sums).
#
# Protocol: uio_in[0] = strobe. Load A (32 bytes), load B (32 bytes),
# compute starts automatically, read C (64 bytes). All MSB first.
# uio_out: [1] busy [2] done [3] load_a [4] load_b [5] compute [6] read [7] byte_valid

import random
import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, RisingEdge

MIN16, MAX16 = -32768, 32767


def to_s16(x):
    x &= 0xFFFF
    return x - 0x10000 if x & 0x8000 else x


def to_s32(x):
    x &= 0xFFFFFFFF
    return x - 0x100000000 if x & 0x80000000 else x


def ref_matmul(a, b):
    return [[to_s32(sum(to_s16(a[i][k]) * to_s16(b[k][j]) for k in range(4)))
             for j in range(4)] for i in range(4)]


async def strobe_byte(dut, v):
    dut.ui_in.value = v & 0xFF
    dut.uio_in.value = 1
    await RisingEdge(dut.clk)
    dut.uio_in.value = 0
    await RisingEdge(dut.clk)


async def load_matrix(dut, m):
    for row in m:
        for v in row:
            u = v & 0xFFFF
            await strobe_byte(dut, u >> 8)
            await strobe_byte(dut, u & 0xFF)


async def wait_done(dut, timeout=3000):
    for n in range(timeout):
        await RisingEdge(dut.clk)
        if (int(dut.uio_out.value) >> 2) & 1:
            return n
    raise TimeoutError("done not asserted")


async def read_c(dut):
    out = []
    await RisingEdge(dut.clk)
    assert (int(dut.uio_out.value) >> 7) & 1, "byte_valid low for first byte"
    out.append(int(dut.uo_out.value) & 0xFF)
    for _ in range(63):
        dut.uio_in.value = 1
        await RisingEdge(dut.clk)
        dut.uio_in.value = 0
        await RisingEdge(dut.clk)
        assert (int(dut.uio_out.value) >> 7) & 1, "byte_valid low in read phase"
        out.append(int(dut.uo_out.value) & 0xFF)
    c = [[0] * 4 for _ in range(4)]
    for e in range(16):
        b = out[4 * e:4 * e + 4]
        c[e // 4][e % 4] = to_s32((b[0] << 24) | (b[1] << 16) | (b[2] << 8) | b[3])
    # strobe the final byte out so the wrapper returns to LOAD_A
    dut.uio_in.value = 1
    await RisingEdge(dut.clk)
    dut.uio_in.value = 0
    await RisingEdge(dut.clk)
    return c


async def start(dut):
    cocotb.start_soon(Clock(dut.clk, 20, unit="ns").start())
    dut.ena.value = 1
    dut.ui_in.value = 0
    dut.uio_in.value = 0
    dut.rst_n.value = 0
    await ClockCycles(dut.clk, 10)
    dut.rst_n.value = 1
    await ClockCycles(dut.clk, 5)


async def matmul(dut, a, b):
    await load_matrix(dut, a)
    await load_matrix(dut, b)
    lat = await wait_done(dut)
    c = await read_c(dut)
    return c, lat


def check(c, a, b, label):
    exp = ref_matmul(a, b)
    for i in range(4):
        for j in range(4):
            assert c[i][j] == exp[i][j], f"{label}: C[{i}][{j}] got {c[i][j]} expected {exp[i][j]}"


def const(v):
    return [[v] * 4 for _ in range(4)]


IDENT = [[1 if i == j else 0 for j in range(4)] for i in range(4)]
IDENT_Q15 = [[MAX16 if i == j else 0 for j in range(4)] for i in range(4)]


@cocotb.test()
async def test_reset_idle(dut):
    await start(dut)
    s = int(dut.uio_out.value)
    assert (s >> 1) & 1 == 0, "busy after reset"
    assert (s >> 3) & 1 == 1, "load_a phase expected after reset"
    assert (s >> 6) & 1 == 0 and (s >> 7) & 1 == 0


@cocotb.test()
async def test_zero(dut):
    await start(dut)
    a = [[5, -7, 9, 11]] * 4
    c, _ = await matmul(dut, const(0), a)
    check(c, const(0), a, "zero x X")
    c, _ = await matmul(dut, const(0), const(0))
    check(c, const(0), const(0), "zero x zero")


@cocotb.test()
async def test_identity(dut):
    await start(dut)
    a = [[1, -2, 3, -4], [5, -6, 7, -8], [9, -10, 11, -12], [13, -14, 15, -16]]
    c, _ = await matmul(dut, a, IDENT)
    check(c, a, IDENT, "A x I")
    assert c == a
    c, _ = await matmul(dut, IDENT, a)
    assert c == a
    c, _ = await matmul(dut, a, IDENT_Q15)  # Q15 'one' = 32767 (raw Q30 result)
    check(c, a, IDENT_Q15, "A x I_q15")


@cocotb.test()
async def test_positive(dut):
    await start(dut)
    a = [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]]
    b = [[17, 18, 19, 20], [21, 22, 23, 24], [25, 26, 27, 28], [29, 30, 31, 32]]
    c, _ = await matmul(dut, a, b)
    check(c, a, b, "positive")
    c, _ = await matmul(dut, const(1), const(1))
    assert c == const(4)


@cocotb.test()
async def test_negative_and_mixed(dut):
    await start(dut)
    a = [[-1, -2, -3, -4], [-5, -6, -7, -8], [-9, -10, -11, -12], [-13, -14, -15, -16]]
    b = [[-17, -18, -19, -20], [-21, -22, -23, -24], [-25, -26, -27, -28], [-29, -30, -31, -32]]
    c, _ = await matmul(dut, a, b)
    check(c, a, b, "neg x neg")
    m = [[1, -2, 3, -4], [-5, 6, -7, 8], [9, -10, 11, -12], [-13, 14, -15, 16]]
    c, _ = await matmul(dut, a, m)
    check(c, a, m, "neg x mixed")
    c, _ = await matmul(dut, m, b)
    check(c, m, b, "mixed x neg")


@cocotb.test()
async def test_extremes(dut):
    await start(dut)
    cases = [
        (const(MIN16), const(MIN16)),   # (-32768)^2 * 4 = 2^32 -> wraps to 0
        (const(MAX16), const(MAX16)),
        (const(MIN16), const(MAX16)),
        (const(MAX16), const(MIN16)),
        ([[MIN16, MAX16, MIN16, MAX16]] * 4, [[MAX16, MIN16, MIN16, MAX16]] * 4),
        (const(-1), const(MIN16)),
        (const(1), const(MIN16)),
    ]
    for n, (a, b) in enumerate(cases):
        c, _ = await matmul(dut, a, b)
        check(c, a, b, f"extreme case {n}")


@cocotb.test()
async def test_overflow_boundary(dut):
    """4*(-32768)^2 = 2^32 wraps to 0; 3 terms of 2^30 + one 2^30-1 stays positive max-ish."""
    await start(dut)
    a = [[MIN16, MIN16, MIN16, MIN16]] * 4
    b = [[MIN16] * 4] * 4
    c, _ = await matmul(dut, a, b)
    assert c == const(0)
    a = [[MIN16, MIN16, MIN16, MAX16]] * 4          # 3*2^30 + (-32768*32767) positive 32-bit wrap check
    b = [[MIN16] * 4, [MIN16] * 4, [MIN16] * 4, [MAX16] * 4]
    c, _ = await matmul(dut, a, b)
    check(c, a, b, "overflow wrap")


@cocotb.test()
async def test_booth_digit_patterns(dut):
    """Every Booth digit pattern: each 16-bit operand built from all 8-bit windows."""
    await start(dut)
    vals = [0x0000, 0x5555, 0xAAAA, 0xFFFF, 0x7FFF, 0x8000, 0x1234, 0xEDCB]
    for n in range(0, 256, 16):
        a = [[to_s16((n + r * 4 + k) * 0x0101) for k in range(4)] for r in range(4)]
        b = [[to_s16(vals[(n // 16 + k + col) % 8]) for col in range(4)] for k in range(4)]
        c, _ = await matmul(dut, a, b)
        check(c, a, b, f"booth patterns {n}")


@cocotb.test()
async def test_random_back_to_back(dut):
    await start(dut)
    rng = random.Random(1234)
    for n in range(12):
        a = [[rng.randint(MIN16, MAX16) for _ in range(4)] for _ in range(4)]
        b = [[rng.randint(MIN16, MAX16) for _ in range(4)] for _ in range(4)]
        c, _ = await matmul(dut, a, b)     # no reset between operations
        check(c, a, b, f"random back-to-back {n}")


@cocotb.test()
async def test_reset_mid_operation(dut):
    await start(dut)
    a = [[3, 4, 5, 6]] * 4
    await load_matrix(dut, a)
    await load_matrix(dut, a)       # compute now running
    await ClockCycles(dut.clk, 10)
    dut.rst_n.value = 0
    await ClockCycles(dut.clk, 3)
    dut.rst_n.value = 1
    await ClockCycles(dut.clk, 3)
    s = int(dut.uio_out.value)
    assert (s >> 3) & 1 == 1 and (s >> 1) & 1 == 0
    b = [[-9, 8, -7, 6]] * 4
    c, _ = await matmul(dut, b, a)
    check(c, b, a, "after mid-op reset")


@cocotb.test()
async def test_latency_report(dut):
    await start(dut)
    _, lat = await matmul(dut, const(7), const(9))
    dut._log.info(f"compute latency (cycles from last B byte to done): {lat}")
