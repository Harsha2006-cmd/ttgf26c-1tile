## How it works

One serial radix-4 modified Booth multiply-accumulate engine, driven byte-serially. Inputs are signed
16-bit (INT16 or Q15). Each dot product `C[i][j] = sum_k A[i][k]*B[k][j]` has 4 terms and a signed
32-bit result that wraps modulo 2^32. **No Q15 rescale, rounding or saturation is applied**: for Q15
inputs the output is a raw Q30 value.

A 4x4 matrix product is 16 dot products, sequenced by the host (a microcontroller). The chip does not
store the matrices: they would not fit one tile.

Each Booth digit (8 per 16-bit multiplier) is added into the accumulator per clock, so each term takes
8 clocks (`busy` high).

## Protocol

Pulse `uio[0]` (strobe) for one clock per byte while `ui_in` holds the byte.

1. For each of the 4 terms k: send A[i][k] high byte, A[i][k] low byte, B[k][j] high byte, B[k][j] low
   byte. After the 4th byte the chip multiplies for 8 clocks (`uio[1]` busy); wait until `uio[3]` (load)
   is high again before the next term.
2. After the 4th term the read phase starts (`uio[6]`, with `uio[2]` done pulse). Read 4 bytes of the
   result from `uo_out`, MSB first, pulsing strobe after each byte.
3. The chip returns to the load phase for the next dot product.

Status: `uio[1]` busy, `uio[2]` done pulse, `uio[3]` load phase, `uio[5]` compute, `uio[6]` read phase,
`uio[7]` byte valid.

## External hardware

None; a microcontroller or the Tiny Tapeout demo board drives strobe and data.
