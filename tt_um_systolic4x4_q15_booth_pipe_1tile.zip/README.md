# Q15/INT16 matrix-multiply MAC (serial radix-4 Booth) - Tiny Tapeout TTGF26c, 1x1 tile

Top module `tt_um_systolic4x4_q15_booth_pipe`. Datasheet text in `docs/info.md`.

## Status (read this first)

| Item | Status |
|---|---|
| RTL simulation (cocotb, Icarus) | 11/11 pass vs an independent Python model |
| Test strength | planting an arithmetic bug makes 10 of 11 tests fail |
| Yosys synthesis, GF180 7-track cells | about 16,200 um^2, 125 flops (pre-placement estimate) |
| LibreLane hardening, DRC, LVS, timing, precheck, gate-level test, GDS | **NOT RUN** - run the `gds` workflow |

A 1x1 tile is about 340 x 160 um = 54,400 um^2 gross, so this uses roughly 30% before placement and
routing overhead. `clock_hz: 10000000` is a conservative guess to check against the timing report.

## Architecture change (needed for one tile)

The 16-PE systolic array with on-chip matrices synthesizes to about 253,000 um^2 (needs about 4x2
tiles; a 4x4 matrix pair alone is about 47,000 um^2 of storage). One tile cannot hold it. This version
keeps the serial radix-4 Booth MAC and byte-serial interface, but has ONE MAC and no on-chip matrices:
the host feeds operand pairs for each of the 16 dot products of a 4x4 product. It is no longer a
systolic array. The 16-PE versions are kept in `archive/` (`original_4x4_pipelined/`, `serial_16pe_4x2/`).

## Simulation

```
pip install -r test/requirements.txt
sudo apt-get install iverilog
cd test && make && python -m cocotb_tools.check_results results.xml
```
